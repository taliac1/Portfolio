import json

from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps, loads

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:44815/?authSource=test' % ('aacuser', '1234'))
        # where xxxx is your unique port number
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            return self.database.animals.insert(data)  # data should be dictionary 
        else:
            raise Exception("Nothing to create, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, criteria=None):
        if criteria is not None:
            data = self.database.animals.find(criteria,{"_id": False})
        else:
            data = self.database.animals.find({},{"_id": False})
        
        return data
    
    # Create method to implement the U in CRUD.
    def update(self, searchData, updateData):
        if searchData is not None:
            result = self.database.animals.update_many(searchData, { "$set": updateData})
        else:
            return "{}"
        return result.raw_result
            
    def delete(self, data):
        if data is not None:
            dataD = self.database.animals.delete_one(data)
            return dataD
        else:
            raise Exception("Nothing to search, because data parameter is empty")

